﻿using System.Collections.Generic;
using IEntity = models.IEntity;
using MOVEMENT = models.MOVEMENT;
using IPlayer = models.IPlayer;
using Point2D = models.Point2D;
using RandomSpawnStrategy = models.RandomSpawnStrategy;
using ISpawnStrategy = models.ISpawnStrategy;
using IWorldMap = models.IWorldMap;
using WorldMapImpl = models.WorldMapImpl;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace worldMapTest
{

	[TestClass]
	public class WorldMapTest
	{
		private static int WIDTH = 51;
		private static int HEIGHT = 51;
		private static int NUM_ENEMIES = 5;
		private static int NUM_COLLECTABLES = 15;
		private static int EXPECTED_SIZE = 5;

		private ISpawnStrategy randomStrategy = new RandomSpawnStrategy();
		private IWorldMap worldMap;
		private Point2D startPlayerPos = new Point2D(WIDTH / 2, HEIGHT / 2);
		private Point2D randomPos = new Point2D(3, EXPECTED_SIZE);


		[TestMethod]
		public void testRandomSpawnStrategy()
		{
			int width = 10;
			int height = 10;
			int numEntities = 4;
			ISet<Point2D> set1 = this.randomStrategy.getSpawnPoints(width, height, numEntities);
			set1.Add(randomPos);
			ISet<Point2D> set2 = this.randomStrategy.getSpawnPoints(width, height, numEntities);
			set2.Add(randomPos);
			ISet<Point2D> allSet = this.randomStrategy.getDoubleSpawnPoints(width, height, set1, set2);
			Assert.AreEqual(EXPECTED_SIZE, set1.Count);
			Assert.True(EXPECTED_SIZE * 2, allSet.Count);
			Assert.True(allSet.ContainsAll(set1));
			Assert.True(allSet.ContainsAll(set2));
		}

		[TestMethod]
		public void testWorldMapCreation()
		{
			IDictionary<Point2D, Optional<Entity>> board = worldMap.getBoard();
			long count = board.Values.Where(v => v.isPresent()).Count();
			Assert.AreEqual(WIDTH * HEIGHT, board.Count);
			Assert.True(board[startPlayerPos].get() is Player);
			Assert.AreEqual(NUM_ENEMIES + NUM_COLLECTABLES + 1, count);
		}

		[TestMethod]
		public void testMovePlayer()
		{
			worldMap.movePlayer(MOVEMENT.LEFT);
			worldMap.movePlayer(MOVEMENT.UP);
			IDictionary<Point2D, Optional<Entity>> board = worldMap.getBoard();
			Point2D leftPosition = new Point2D(24, 26);
			Assert.True(board[leftPosition].isPresent());
			Assert.True(board[leftPosition].get() is Player);
			Assert.True(board[startPlayerPos].isEmpty());
		}
	}

}

//Class imported to better use Collections

using System;
using System.Collections.Generic;

internal static class CollectionHelper
{
	public static bool ContainsAll<T>(this ICollection<T> c1, ICollection<T> c2)
	{
		if (c2 is null)
			throw new NullReferenceException();

		foreach (T item in c2)
		{
			if (!c1.Contains(item))
				return false;
		}
		return true;
	}

	public static bool RemoveAll<T>(this ICollection<T> c1, ICollection<T> c2)
	{
		if (c2 is null)
			throw new NullReferenceException();

		bool changed = false;
		foreach (T item in c2)
		{
			if (c1.Contains(item))
			{
				c1.Remove(item);
				changed = true;
			}
		}
		return changed;
	}

	public static bool RetainAll<T>(this ICollection<T> c1, ICollection<T> c2)
	{
		if (c2 is null)
			throw new NullReferenceException();

		bool changed = false;
		T[] arrayCopy = new T[c1.Count];
		c1.CopyTo(arrayCopy, 0);
		foreach (T item in arrayCopy)
		{
			if (!c2.Contains(item))
			{
				c1.Remove(item);
				changed = true;
			}
		}
		return changed;
	}
}