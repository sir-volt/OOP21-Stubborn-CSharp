﻿namespace models
{
	public interface ICollectable : IEntity
	{

		int Points {get;}

	}

}