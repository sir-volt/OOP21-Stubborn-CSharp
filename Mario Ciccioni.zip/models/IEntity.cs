﻿namespace models
{
	public interface IEntity
	{
		Point2D Position {get;set;}
	}
}