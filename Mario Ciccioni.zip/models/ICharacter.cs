﻿namespace models
{
	public interface ICharacter : IEntity
	{
		int Health {get;set;}
	}
}