﻿namespace models
{
	public interface IPlayer : IEntity
	{

	}
}