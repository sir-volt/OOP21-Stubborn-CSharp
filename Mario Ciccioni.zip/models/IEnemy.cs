﻿namespace models
{
	public interface IEnemy : IEntity
	{
		AiEnemy Ai {get;}
	}
}